# Backend Theory

This folder contains written assignments and database-related practical work for the Backend Development course.

## Assignments

| Assignment | Topic | Documentation |
|---|---|---|
| Assignment 01 | Browser-based Notes App using HTML, CSS, JavaScript, LocalStorage, and JSON | [Open README](./Assignment%2001%20-%20Notes%20App/README.md) · [Open assignment](./Assignment%2001%20-%20Notes%20App/assignment01.md) |
| Assignment 02 | PostgreSQL as SQL + NoSQL using JSONB | [Open README](./Assignment%2002%20-%20PostgreSQL%20JSONB/README.md) · [Open assignment](./Assignment%2002%20-%20PostgreSQL%20JSONB/assignment02.md) |

## Topics Covered

- HTML, CSS, and JavaScript
- LocalStorage and JSON
- DOM manipulation and client-side CRUD operations
- PostgreSQL and SQL
- JSON versus JSONB
- JSONB operators, updates, and GIN indexes
- `EXPLAIN ANALYZE`
- PostgreSQL JSONB versus MongoDB
