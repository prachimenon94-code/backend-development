# Assignment 02 — PostgreSQL as SQL + NoSQL: Working with JSONB

This assignment explores how PostgreSQL supports relational data and flexible NoSQL-style data using the `JSONB` data type.

## Objectives

- Understand `JSONB` and compare it with `JSON`
- Store flexible product attributes in a relational table
- Use `->`, `->>`, `@>`, and `?` operators
- Update JSONB values and create GIN indexes
- Use `EXPLAIN ANALYZE`
- Compare PostgreSQL JSONB with MongoDB

## Technologies Used

PostgreSQL, SQL, JSONB, MongoDB, and MongoDB Shell.

## Files

- [`assignment02.md`](./assignment02.md) — complete assignment documentation
- [`README.md`](./README.md) — assignment overview

## Example Query

```sql
SELECT name
FROM products
WHERE attributes @> '{"wireless": true}';
```

The practical implements a product catalog and covers product insertion, JSONB queries, updates, indexing, and query-performance analysis.
