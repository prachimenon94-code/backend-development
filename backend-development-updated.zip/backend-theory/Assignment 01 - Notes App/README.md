# Assignment 01 — Notes App

A browser-based Notes application developed using HTML, CSS, and JavaScript. It demonstrates LocalStorage, JSON, DOM manipulation, searching, and CRUD-style operations without a backend server.

## Features

- Create, edit, delete, and complete notes
- Search notes by title or content
- Persistent storage using `localStorage`
- JSON serialization and deserialization
- Creation and update timestamps

## Technologies Used

HTML5, CSS3, JavaScript, LocalStorage, and JSON.

## Files

- [`index.html`](./index.html) — application structure
- [`style.css`](./style.css) — styling and responsive layout
- [`script.js`](./script.js) — note and LocalStorage logic
- [`assignment01.md`](./assignment01.md) — assignment documentation
- [`notes-screenshot.png`](./notes-screenshot.png) — screenshot

## How to Run

Open [`index.html`](./index.html) in a browser or use the VS Code Live Server extension. No installation or database is required.
