# Backend Development

This repository contains my coursework, laboratory projects, assignments, and practical implementations for the **Backend Development** course. It covers frontend foundations, backend programming, REST APIs, authentication, server-side rendering, MongoDB, PostgreSQL, JSON, JSONB, and browser storage.

## Repository Structure

```text
backend-development/
├── backend-lab/
│   ├── cms-lab/
│   ├── todo-app/
│   ├── exp-03-responsive-page/
│   ├── exp-05-javascript-basics/
│   ├── exp-12a-express-ejs/
│   ├── exp-13-mongodb-auth/
│   └── exp-14-postgresql/
├── backend-theory/
│   ├── Assignment 01 - Notes App/
│   └── Assignment 02 - PostgreSQL JSONB/
└── README.md
```

## Backend Lab

The complete lab index is available in the [Backend Lab README](./backend-lab/README.md).

| Project / Experiment | Description | README |
|---|---|---|
| CMS Lab | Content Management System using Node.js, Express, EJS, MongoDB, and Mongoose. Includes post creation, viewing, editing, and deletion. | [Open README](./backend-lab/cms-lab/README.md) |
| Todo App | Todo API with user registration, login, JWT authentication, protected routes, and MongoDB CRUD operations. | [Open README](./backend-lab/todo-app/README.md) |
| Experiment 03 | Responsive web page using HTML5, CSS3, Flexbox, Grid, and media queries. | [Open README](./backend-lab/exp-03-responsive-page/README.md) |
| Experiment 05 | JavaScript practical using arrays of objects, arrow functions, `map()`, `reduce()`, spread syntax, averages, and JSON output. | [Open README](./backend-lab/exp-05-javascript-basics/README.md) |
| Experiment 12A | Server-side rendered application using Node.js, NPM, Express, Nodemon, EJS, routes, and forms. | [Open README](./backend-lab/exp-12a-express-ejs/README.md) |
| Experiment 13 | Registration and login system using Express, MongoDB, Mongoose, sessions, bcrypt, EJS, and environment variables. | [Open README](./backend-lab/exp-13-mongodb-auth/README.md) |
| Experiment 14 | Express application connected to PostgreSQL for inserting and displaying student records using parameterized SQL. | [Open README](./backend-lab/exp-14-postgresql/README.md) |

## Backend Theory

The complete theory index is available in the [Backend Theory README](./backend-theory/README.md).

| Assignment | Description | README | Assignment Document |
|---|---|---|---|
| Assignment 01 — Notes App | Browser-based notes application using HTML, CSS, JavaScript, LocalStorage, JSON, searching, and CRUD-style operations. | [Open README](./backend-theory/Assignment%2001%20-%20Notes%20App/README.md) | [Open assignment](./backend-theory/Assignment%2001%20-%20Notes%20App/assignment01.md) |
| Assignment 02 — PostgreSQL JSONB | Product catalog practical covering JSONB queries, updates, operators, GIN indexes, `EXPLAIN ANALYZE`, and comparison with MongoDB. | [Open README](./backend-theory/Assignment%2002%20-%20PostgreSQL%20JSONB/README.md) | [Open assignment](./backend-theory/Assignment%2002%20-%20PostgreSQL%20JSONB/assignment02.md) |

## Technologies Used

- HTML5 and CSS3
- JavaScript
- Node.js and NPM
- Express.js and EJS
- MongoDB and Mongoose
- PostgreSQL and SQL
- JSON and JSONB
- JWT and session-based authentication
- bcrypt
- LocalStorage
- Nodemon and environment variables

## Concepts Covered

- Client-server architecture
- HTTP and REST APIs
- Express routing and middleware
- Server-side rendering
- Authentication and authorization
- JWT and session-based authentication
- CRUD operations
- MongoDB and Mongoose models
- PostgreSQL and parameterized SQL queries
- JSONB operators and database indexing
- Responsive web design
- JavaScript array methods
- Browser LocalStorage and JSON

## Running the Projects

Each project contains its own setup instructions. For Node.js projects, move into the relevant folder, install dependencies, and run the development script:

```bash
cd backend-lab/<project-folder>
npm install
npm run dev
```

Browser-based projects can be opened directly in a browser or launched with VS Code Live Server. Database projects require their respective MongoDB or PostgreSQL service to be running.

## Security and GitHub Notes

- Do not upload `.env` files, passwords, database credentials, API keys, or tokens.
- Do not upload `node_modules`.
- Use `.env.example` files as configuration templates.
- Keep database credentials private.

## Author

**Prachi Menon**  
B.Tech Computer Science Engineering  
UPES Dehradun
