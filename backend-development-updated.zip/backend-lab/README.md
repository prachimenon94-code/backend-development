# Backend Development Lab

This folder contains the practical projects and experiments completed for the Backend Development course. Each project has its own README with its objective, technologies, implementation details, and instructions.

## Projects and Experiments

| Project | Description | Documentation |
|---|---|---|
| CMS Lab | Content Management System using Express and MongoDB | [Open README](./cms-lab/README.md) |
| Todo App | JWT-authenticated Todo API using MongoDB | [Open README](./todo-app/README.md) |
| Experiment 03 | Responsive web page using HTML5 and CSS3 | [Open README](./exp-03-responsive-page/README.md) |
| Experiment 05 | JavaScript arrays, objects, functions, and array methods | [Open README](./exp-05-javascript-basics/README.md) |
| Experiment 12A | Node.js, NPM, Express, Nodemon, and EJS | [Open README](./exp-12a-express-ejs/README.md) |
| Experiment 13 | MongoDB, Mongoose, sessions, and authentication | [Open README](./exp-13-mongodb-auth/README.md) |
| Experiment 14 | Express application connected to PostgreSQL | [Open README](./exp-14-postgresql/README.md) |

## Technologies Used

- HTML5, CSS3, and JavaScript
- Node.js, NPM, Express.js, and EJS
- MongoDB, Mongoose, PostgreSQL, and SQL
- JWT, sessions, bcrypt, and environment variables

## Security Notes

Never commit `.env` files, credentials, API keys, database dumps, or `node_modules`. Use `.env.example` files as configuration templates.
