# Experiment 05 — JavaScript Arrays, Objects and Functions

## Objective

To demonstrate JavaScript arrays, objects, functions, arrow functions, and array methods through a student-data practical.

## Concepts Demonstrated

- Arrays of objects and arrow functions
- `map()`, `reduce()`, and spread syntax
- Student average calculation and finding the topper
- Displaying JSON output in the browser

## Files

- [`index.html`](./index.html) — webpage and output area
- [`script.js`](./script.js) — JavaScript implementation

## How to Run

Open [`index.html`](./index.html) in a browser and click **Run Experiment**.
