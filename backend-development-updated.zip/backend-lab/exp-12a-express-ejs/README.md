# Experiment 12A — Node.js, NPM, Express, Nodemon and EJS

## Objective

To develop a server-side rendered web application using Node.js, Express.js, Nodemon, and EJS.

## Concepts Demonstrated

- Node.js server setup and NPM package management
- Express GET and POST routes
- Form handling, EJS templates, and static files
- Nodemon development workflow

## How to Run

```bash
cd exp-12a-express-ejs
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000). The production command is `npm start`.
