# Experiment 03 — Responsive Web Page

## Objective

To create a responsive web page using HTML5 and CSS3 without a framework.

## Concepts Demonstrated

- Semantic HTML and viewport meta tag
- CSS Flexbox and Grid
- Media queries
- Responsive navigation, cards, and footer

## Files

- [`index.html`](./index.html) — webpage structure
- [`style.css`](./style.css) — responsive styling

## How to Run

Open [`index.html`](./index.html) in a browser or use the VS Code Live Server extension.
