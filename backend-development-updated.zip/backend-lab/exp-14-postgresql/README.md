# Experiment 14 — PostgreSQL

## Objective

To build an Express application connected to PostgreSQL for inserting and displaying student records.

## Concepts Demonstrated

- PostgreSQL database connection and schema creation
- Express routes and parameterized SQL queries
- Insert and select operations
- Connection strings and environment variables

## How to Run on Windows

```bash
cd exp-14-postgresql
npm install
copy .env.example .env
npm run dev
```

## How to Run on macOS/Linux

```bash
cd exp-14-postgresql
npm install
cp .env.example .env
npm run dev
```

Create a PostgreSQL database named `backend_lab`, run [`schema.sql`](./schema.sql), configure `DATABASE_URL` in `.env`, and open [http://localhost:3002](http://localhost:3002). Never commit `.env`.
