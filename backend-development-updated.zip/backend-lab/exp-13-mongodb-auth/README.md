# Experiment 13 — MongoDB, Mongoose and Authentication

## Objective

To create a user registration and login system using Express.js, MongoDB, Mongoose, sessions, and bcrypt.

## Concepts Demonstrated

- User registration, login, and logout
- MongoDB connection and Mongoose models
- Password hashing with bcrypt
- Session-based authentication
- EJS forms and environment variables

## How to Run on Windows

```bash
cd exp-13-mongodb-auth
npm install
copy .env.example .env
npm run dev
```

## How to Run on macOS/Linux

```bash
cd exp-13-mongodb-auth
npm install
cp .env.example .env
npm run dev
```

Start MongoDB before running the application and open [http://localhost:3001](http://localhost:3001). Never commit `.env`.
